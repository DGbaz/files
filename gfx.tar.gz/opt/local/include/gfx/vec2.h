#ifndef _GFX_VEC2_H_
#define _GFX_VEC2_H_

#include <math.h>

typedef struct _Vec2 {
	float x, y;
} Vec2;

typedef struct _LineSegment {
	Vec2 a, b;
} LineSegment;

static inline Vec2 vec2_add(Vec2 a, Vec2 b) { return (Vec2){ a.x + b.x, a.y + b.y }; }
static inline Vec2 vec2_sub(Vec2 a, Vec2 b) { return (Vec2){ a.x - b.x, a.y - b.y }; }
static inline Vec2 vec2_scale(Vec2 a, float b) { return (Vec2){ a.x * b, a.y * b }; }
static inline float vec2_dot(Vec2 a, Vec2 b) { return (a.x * b.x) + (a.y * b.y); }
static inline float vec2_len(Vec2 a) {
	return sqrt(sqr(a.x) + sqr(a.y));
}
static inline float vec2_len_sqr(Vec2 a) { return sqr(a.x) + sqr(a.y); }
static inline Vec2 vec2_normalize(Vec2 a) {
	float len = vec2_len(a);
	if (len <= 0.0)
		return (Vec2){ 0, 0 };
	return vec2_scale(a, 1.0 / len);
}
static inline Vec2 vec2_cross(Vec2 u) {
	Vec2 r;
	r.x = u.y;
	r.y = -u.x;
	return r;
}
static inline float vec2_dist(Vec2 a, Vec2 b) { return vec2_len(vec2_sub(a, b)); }
static inline float vec2_dist_sqr(Vec2 a, Vec2 b) { return vec2_len_sqr(vec2_sub(a, b)); }
static inline Vec2 vec2_interpolate(Vec2 a, Vec2 b, float f) {
	return (Vec2){ 
		f * a.x + (1.0f - f) * b.x,
		f * a.y + (1.0f - f) * b.y };
}
static inline gfx_bool vec2_equals(Vec2 a, Vec2 b) {
	return a.x == b.x && a.y == b.y;
}
static inline Vec2 vec2_rotate(Vec2 v, float rads) {
    return (Vec2){
        v.x * cosf(rads) - v.y * sinf(rads),
        v.x * sinf(rads) + v.y * cosf(rads)};
}
static inline float vec2_angle_between(Vec2 v1, Vec2 v2) {
    float angle = atan2(v1.y, v1.x) - atan2(v2.y, v2.x);
    return angle;
}
static inline gfx_bool vec2_intersect_line(LineSegment L1, LineSegment L2, Vec2 *p) {
    float denominator, a, b, numerator1, numerator2;
    denominator = ((L2.b.y - L2.a.y) * (L1.b.x - L1.a.x)) - ((L2.b.x - L2.a.x) * (L1.b.y - L1.a.y));
    if (denominator == 0)
        return 0;
    a = L1.a.y - L2.a.y;
    b = L1.a.x - L2.a.x;
    numerator1 = ((L2.b.x - L2.a.x) * a) - ((L2.b.y - L2.a.y) * b);
    numerator2 = ((L1.b.x - L1.a.x) * a) - ((L1.b.y - L1.a.y) * b);
    a = numerator1 / denominator;
    b = numerator2 / denominator;
    *p = (Vec2){L1.a.x + (a * (L1.b.x - L1.a.x)),
                  L1.a.y + (a * (L1.b.y - L1.a.y))};
    return 1;
}
#endif