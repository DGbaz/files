#ifndef _GFX_H
#define _GFX_H

typedef unsigned char gfx_bool;

#define sqr(x) ((x)*(x))
#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif
#ifndef clamp
#define clamp(v,a,b)        (max((a), min((v), (b))))
#endif
#ifndef M_PI
#    define M_PI 3.14159265358979323846
#endif
#define gfx_radians(degrees) ((float)(degrees) * M_PI / 180.0)
#define gfx_degrees(radians) ((float)(radians) * 180.0 / M_PI)

#include "vec2.h"
#include <stdio.h>
#include <time.h>

enum GfxBlendMode {
    BLEND_CLEAR,
    BLEND_SRC,
    BLEND_DST,
    BLEND_SRC_OVER,
    BLEND_DST_OVER,
    BLEND_SRC_IN,
    BLEND_DST_IN,
    BLEND_SRC_OUT,
    BLEND_DST_OUT,
    BLEND_SRC_ATOP,
    BLEND_DST_ATOP,
    BLEND_XOR,
    BLEND_PLUS,
    BLEND_MODULATE,
    BLEND_SCREEN,
    BLEND_OVERLAY,
    BLEND_DARKEN,
    BLEND_LIGHTEN,
    BLEND_COLOR_DODGE,
    BLEND_COLOR_BURN,
    BLEND_HARD_LIGHT,
    BLEND_SOFT_LIGHT,
    BLEND_DIFFERENCE,
    BLEND_EXCLUSION,
    BLEND_MULTIPLY,
    BLEND_HUE,
    BLEND_SATURATION,
    BLEND_COLOR,
    BLEND_LUMINOSITY
};

enum GfxStrokeCap {
   STROKE_CAP_NONE,
   STROKE_CAP_ROUNDED,
   STROKE_CAP_BLUNT
};

enum GfxStrokeJoin {
	STROKE_JOIN_MITER,
	STROKE_JOIN_ROUNDED,
	STROKE_JOIN_BEVEL
};

enum GfxFillType {
    FILL_WINDING,
    FILL_EVEN_ODD, 
    FILL_INVERSE_WINDING,
    FILL_INVERSE_EVEN_ODD
};

enum GfxFormat {
	FORMAT_RGBA,
	FORMAT_GRAYSCALE,
        FORMAT_BGRA,
        FORMAT_RGBx,
        FORMAT_BGRx
};

enum GfxFilter {
	FILTER_NEAREST,
	FILTER_BILINEAR
};

enum GfxFilterQuality {
    FILTER_QUALITY_NONE,
    FILTER_QUALITY_LOW,
    FILTER_QUALITY_MEDIUM,
    FILTER_QUALITY_HIGH
};

enum GfxClipOp {
  CLIP_OP_DIFFERENCE,
  CLIP_OP_INTERSECT
};

enum GfxTileMode {
  TILE_CLAMP,
  TILE_REPEAT,
  TILE_MIRROR,
  TILE_DECAL
};

typedef struct _GfxTextExtents {
  float w, h;
  float ascent, descent;
  float line_height;
  float cap_height;
} GfxTextExtents;

typedef struct _GfxMat {
    float m[9];
} GfxMat;

#ifndef _GFX_IMPLEMENTATION_
typedef struct GfxHandle Gfx;
typedef struct GfxSurfaceHandle GfxSurface;
typedef struct GfxPathHandle GfxPath;
typedef struct GfxFontHandle GfxFont;
typedef enum GfxStrokeCap GfxStrokeCap;
typedef enum GfxStrokeJoin GfxStrokeJoin;
typedef enum GfxFillType GfxFillType;
typedef enum GfxFormat GfxFormat;
typedef enum GfxBlendMode GfxBlendMode;
typedef enum GfxTileMode GfxTileMode;
#else
class Gfx;
class GfxSurface;
class GfxPath;
class GfxState;
class GfxFont;
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned int GfxColor;
typedef void (*GfxSurfaceCallback)(void *, GfxSurface *);

#ifndef __EMSCRIPTEN__
    static inline GfxColor gfx_rgba(float r, float g, float b, float a) {
        return (((int)((float)(a) * 255.0)) << 24 | ((int)((float)(r) * 255.0) << 16) | 
			         ((int)((float)(g) * 255.0) << 8) | ((int)((float)(b) * 255.0)));
    }
#else
    GfxColor gfx_rgba(float r, float g, float b, float a);
#endif

    void gfx_mat33_identity(GfxMat *mat);
    void gfx_mat33_transform(GfxMat *mat, float x, float y, float *px, float *py);
    void gfx_mat33_itransform(GfxMat *mat, float x, float y, float *px, float *py);
    void gfx_mat33_translate(GfxMat *mat, float x, float y);
    void gfx_mat33_concat(GfxMat *mat, GfxMat *with);
    void gfx_mat33_scale(GfxMat *mat, float x, float y);
    void gfx_mat33_rotate(GfxMat *mat, float degrees, float x, float y);
    void gfx_mat33_inverse(GfxMat *mat);

    GfxSurface *gfx_surface_retain(GfxSurface *surface);
    GfxSurface *gfx_surface_release(GfxSurface *surface);
    int gfx_surface_get_ident(GfxSurface *surface);
    int gfx_surface_set_ident(GfxSurface *surface, int ident);

#define gfx_surface_destroy gfx_surface_release

    int gfx_surface_width(GfxSurface *surface);
    int gfx_surface_height(GfxSurface *surface);

    void gfx_surface_set_filter_quality(GfxSurface *surface, enum GfxFilterQuality quality);

    GfxFont *gfx_font_new(const char *face, int point_size);
    GfxFont *gfx_font_new_from_file(const char *face, int point_size,
                                    const char* location, const char* type);
    GfxFont *gfx_font_retain(GfxFont *font);
    void gfx_font_release(GfxFont *font);
    
    GfxPath *gfx_path_new();
    void gfx_path_destroy(GfxPath *path);
    void gfx_path_move_to(GfxPath *path, float x, float y);
    void gfx_path_line_to(GfxPath *path, float x, float y);
    void gfx_path_close(GfxPath *path);
    void gfx_path_clear(GfxPath *path);
    void gfx_path_bezier_to(GfxPath *path, float cp0_x, float cp0_y, float cp1_x, float cp1_y,
		float x, float y);
    void gfx_path_arc_to(GfxPath *path, float cx, float cy, float radius, float rads_from,
		float rads, gfx_bool move_start);

    Gfx *gfx_init(bool hardware_accel, int width, int height);
    void gfx_resize(Gfx *gfx, int width, int height);
    void gfx_destroy(Gfx *gfx);
    int gfx_width(Gfx *gfx);
    int gfx_height(Gfx *gfx);
    void gfx_get_matrix(Gfx *gfx, GfxMat *m);
    void gfx_set_matrix(Gfx *gfx, GfxMat *m);
    void gfx_concat_matrix(Gfx *gfx, GfxMat *mat);
    void gfx_to_world(Gfx *gfx, float x, float y, float *px, float *py);
    void gfx_to_device(Gfx *gfx, float x, float y, float *px, float *py);
    int gfx_is_visible(Gfx *gfx, float x, float y, float w, float h);
    bool gfx_is_gpu(Gfx *gfx);

    void gfx_reset(Gfx *gfx);
    void gfx_set_aa(Gfx *gfx, gfx_bool enabled);
    GfxSurface *gfx_surface(Gfx *gfx, GfxSurface *surface);
    GfxSurface *gfx_new_surface(Gfx *gfx, int width, int height);
    GfxSurface *gfx_surface_from_bytes(Gfx *gfx, int width, int height, GfxFormat format,
		  int stride, unsigned char *bytes, bool is_transparent);
        GfxSurface *gfx_surface_from_writable(Gfx *gfx, int width, int height, GfxFormat format,
		  int stride, unsigned char *bytes);
    int gfx_surface_read(Gfx *gfx, GfxSurface *surface, unsigned char *bytes, int length);
    void *gfx_surface_pixels(Gfx *gfx, GfxSurface *surface);
    GfxSurface *gfx_surface_from_yuv(Gfx *gfx, int width, int height,
                    int y_stride, int u_stride, int v_stride,
                    unsigned char *y_bytes, unsigned char *u_bytes, unsigned char *v_bytes);
    GfxSurface *gfx_surface_from_source(Gfx *gfx, const char *source, GfxSurfaceCallback onload, void *arg);
    GfxSurface *gfx_surface_from_data(Gfx *gfx, const char *mime_type, unsigned char *data, int length);

    GfxSurface *gfx_surface_pdf(Gfx *gfx, const char *title, const char *creator, time_t created_at,
              float dpi, int page_width, int page_height, FILE *fd_output);
    void gfx_surface_pdf_page(GfxSurface *surf);
    void gfx_surface_pdf_output(GfxSurface *surf);
    void gfx_defaults(Gfx *gfx);
    void gfx_identity(Gfx *gfx);
    void gfx_font_select(Gfx *gfx, GfxFont *font);
    void gfx_move_to(Gfx *gfx, float x, float y);
    void gfx_line_to(Gfx *gfx, float x, float y);
    void gfx_bezier_to(Gfx *gfx, float cp0_x, float cp0_y, float cp1_x, float cp1_y,
		float x, float y);
    void gfx_arc_to(Gfx *gfx, float cx, float cy, float radius, float rads_from, float rads,
		gfx_bool move_start);
    void gfx_clear(Gfx *gfx);
    void gfx_close(Gfx *gfx);
    void gfx_clear_color(Gfx *gfx, GfxColor color);
    void gfx_color(Gfx *gfx, GfxColor color);
    void gfx_rounded_rect(Gfx *gfx, float x, float y, float w, float h, float rx, float ry);
    void gfx_rect(Gfx *gfx, float x, float y, float w, float h);
    void gfx_stroke_cap(Gfx *gfx, GfxStrokeCap cap);
    void gfx_stroke_join(Gfx *gfx, GfxStrokeJoin join);
    void gfx_stroke_width(Gfx *gfx, float w);
    void gfx_stroke_scale(Gfx *gfx, float sc);
    void gfx_set_path(Gfx *gfx, GfxPath *path);
    void gfx_fill_type(Gfx *gfx, GfxFillType fill_type);
    void gfx_fill(Gfx *gfx, gfx_bool clear);
    void gfx_stroke(Gfx *gfx, gfx_bool clear);
    void gfx_stroke_dashed(Gfx *gfx, float thickness, float spacing,
        float phase, gfx_bool clear);
    void gfx_clip(Gfx *gfx, enum GfxClipOp op, gfx_bool anti_alias, gfx_bool clear);
    void gfx_scale(Gfx *gfx, float x, float y);
    void gfx_translate(Gfx *gfx, float x, float y);
    void gfx_rotate(Gfx *gfx, float r);
    void gfx_opacity(Gfx *gfx, float o);
    void gfx_draw_surface(Gfx *gfx, GfxSurface *surface, float x, float y);
    void gfx_draw_gaussian(Gfx *gfx, GfxSurface *surface, float x, float y, float sx, float sy);
    void gfx_draw_text(Gfx *gfx, const char *text, int len, float x, float y, GfxColor color);
    void gfx_draw_text_stroked(Gfx *gfx, const char *text, int len, float x, float y, GfxColor color,
        GfxColor stroke_color, float stroke_width);
    void gfx_draw_text_shadow(Gfx *gfx, const char *text, int len, float x, float y, GfxColor color,
        GfxColor shadow_color, float radius, float ox, float oy);
    float gfx_text_extents(Gfx *gfx, const char *text, int len, GfxTextExtents *ext);
    float gfx_text_ellipsis(Gfx *gfx, const char *text, int len, char *out, int max_width,
		GfxTextExtents *ext);
    float gfx_draw_text_ellipsis(Gfx *gfx, const char *text, int len, float x, float y,
		int max_width, GfxColor color);
    GfxSurface *gfx_new_surface(Gfx *gfx, int width, int height);
    void gfx_push(Gfx *gfx);
    void gfx_pop(Gfx *gfx);
    void gfx_flush(Gfx *gfx);
    GfxPath *gfx_get_path(Gfx *gfx);
    void gfx_blend(Gfx *gfx, GfxBlendMode mode);
    void gfx_linear_gradient(Gfx *gfx, double x0, double y0, GfxColor c0, double x1, double y1, GfxColor c1, GfxTileMode mode);
    void gfx_radial_gradient(Gfx *gfx, double x, double y, GfxColor c0, double rads, GfxColor c1, GfxTileMode mode);
#ifdef __cplusplus
}
#endif
#endif
